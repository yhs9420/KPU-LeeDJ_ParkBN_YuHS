package com.amitshekhar.tflite;


import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.wonderkiln.camerakit.CameraKitError;
import com.wonderkiln.camerakit.CameraKitEvent;
import com.wonderkiln.camerakit.CameraKitEventListener;
import com.wonderkiln.camerakit.CameraKitImage;
import com.wonderkiln.camerakit.CameraKitVideo;
import com.wonderkiln.camerakit.CameraView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class CameraActivity extends AppCompatActivity {

    private static final String MODEL_PATH = "mobilenet_quant_v1_224.tflite";
    private static final String LABEL_PATH = "mobileent_labels.txt";
    private static final int INPUT_SIZE = 224;

    private Classifier classifier;

    private Executor executor = Executors.newSingleThreadExecutor();
    private TextView textViewResult ,recommendText;
    private Button btnDetectObject, btnToggleCamera, recommendButton;
    private ImageView imageViewResult;
    private CameraView cameraView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera2);
        cameraView = findViewById(R.id.cameraView);
        imageViewResult = findViewById(R.id.imageViewResult);
        textViewResult = findViewById(R.id.textViewResult);
        textViewResult.setMovementMethod(new ScrollingMovementMethod());

        btnToggleCamera = findViewById(R.id.btnToggleCamera);
        btnDetectObject = findViewById(R.id.btnDetectObject);

        cameraView.addCameraKitListener(new CameraKitEventListener() {
            @Override
            public void onEvent(CameraKitEvent cameraKitEvent) {

            }

            @Override
            public void onError(CameraKitError cameraKitError) {

            }

            @Override
            public void onImage(CameraKitImage cameraKitImage) {

                Bitmap bitmap = cameraKitImage.getBitmap();

                bitmap = Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, false);

                imageViewResult.setImageBitmap(bitmap);

                /*final Bitmap finalBitmap = bitmap;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        imageViewResult.setImageBitmap(finalBitmap);
                    }
                });*/

                final List<Classifier.Recognition> results = classifier.recognizeImage(bitmap);

                textViewResult.setText(results.toString());

            }

            @Override
            public void onVideo(CameraKitVideo cameraKitVideo) {

            }
        });
        btnToggleCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraView.toggleFacing();
            }
        });
        btnDetectObject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraView.captureImage();
            }
        });

        recommendText = findViewById(R.id.recommendText);
        recommendButton = findViewById(R.id.recommendButton);
        String resultText = textViewResult.getText().toString();
        recommendText.setVisibility(View.GONE);
        recommendButton.setVisibility(View.GONE);

        (new Thread(new Runnable()
        {

            @Override
            public void run()
            {
                while (!Thread.interrupted())
                    try
                    {
                        Thread.sleep(500);
                        runOnUiThread(new Runnable() // start actions in UI thread
                        {

                            @Override
                            public void run()
                            {
                                //recommendText.setText(getCurrentTime());
                                String resultText = textViewResult.getText().toString();
                                if(resultText.length()>2){
                                    recommendText.setVisibility(View.VISIBLE);
                                    recommendButton.setVisibility(View.VISIBLE);
                                    recommendText.setText("인식 성공");
                                }
                                else if(resultText.length()==0){
                                    //recommendText.setEnabled(false);
                                    //recommendButton.setEnabled(false);
                                    recommendText.setVisibility(View.GONE);
                                    recommendButton.setVisibility(View.GONE);
                                }else if(resultText.length()==2) {
                                    recommendText.setVisibility(View.VISIBLE);
                                    recommendButton.setVisibility(View.GONE);
                                    recommendText.setText("인식 실패");

                                }
                            }
                        });
                    }
                    catch (InterruptedException e)
                    {
                        // ooops
                    }
            }
        })).start();
    // 현재 시간을 반환

        recommendButton.setOnClickListener(new View.OnClickListener() {
                                               @Override
                                               public void onClick(View view) {
                                                   String str = textViewResult.getText().toString();
                                                   String result;
                                                   final String[] result2;
                                                   final ArrayList<String> selectedItems = new ArrayList<String>();

                                                   result = str.replace("[", "");
                                                   result = result.replace("]", "");
                                                   result = result.replace("(", "");
                                                   result = result.replace(")", "");
                                                   result = result.replace(" ", "");
                                                   result = result.replace(".", "");
                                                   result = result.replace("%", "");
                                                   result = result.replace("0", "");
                                                   result = result.replace("1", "");
                                                   result = result.replace("2", "");
                                                   result = result.replace("3", "");
                                                   result = result.replace("4", "");
                                                   result = result.replace("5", "");
                                                   result = result.replace("6", "");
                                                   result = result.replace("7", "");
                                                   result = result.replace("8", "");
                                                   result = result.replace("9", "");
                                                   result = result.replace("tomato", "토마토");
                                                   result = result.replace("apple", "사과");
                                                   result = result.replace("banana", "바나나");
                                                   result2 = result.split(",");
                                                   boolean[] checkedList = new boolean[]{false, false, false};
                                                   AlertDialog.Builder dialog = new AlertDialog.Builder(CameraActivity.this);
                                                   dialog.setTitle("식재료 선택")
                                                           .setMultiChoiceItems(result2, checkedList,
                                                                   new DialogInterface.OnMultiChoiceClickListener() {
                                                                       @Override
                                                                       public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                                                                           if (isChecked) {
                                                                               //Toast.makeText(CameraActivity.this, result2[which], Toast.LENGTH_SHORT).show();
                                                                               selectedItems.add(result2[which]);
                                                                           } else {
                                                                               selectedItems.remove(result2[which]);
                                                                           }
                                                                       }
                                                                   })
                                                           .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                                               @Override
                                                               public void onClick(DialogInterface dialog, int which) {
                                                                   if (selectedItems.size() == 0) {
                                                                       Toast.makeText(CameraActivity.this, "선택된 식재료가 없습니다.", Toast.LENGTH_SHORT).show();
                                                                   } else {
                                                                       String items = "";
                                                                       for (String selectedItem : selectedItems) {
                                                                           items += (selectedItem + ", ");
                                                                       }
                                                                       items = items.substring(0, items.length()-2);
                                                                       Intent intent = new Intent(getApplicationContext(), RecommendActivity.class);
                                                                       intent.putExtra("recipe_ingredient", items);
                                                                       startActivity(intent);
                                                                       selectedItems.clear();

                                                                       items = items.substring(0, items.length() - 2);
                                                                   }
                                                               }
                                                           }).create().show();

                                               }});

        initTensorFlowAndLoadModel();

    }

    public String getCurrentTime(){
        long time = System.currentTimeMillis();

        SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");

        String str = dayTime.format(new Date(time));

        return str;
    }

    @Override
    protected void onResume() {
        super.onResume();
        cameraView.start();
    }

    @Override
    protected void onPause() {
        cameraView.stop();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.execute(new Runnable() {
            @Override
            public void run() {
                classifier.close();
            }
        });
    }

    private void initTensorFlowAndLoadModel() {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    classifier = TensorFlowImageClassifier.create(
                            getAssets(),
                            MODEL_PATH,
                            LABEL_PATH,
                            INPUT_SIZE);
                    makeButtonVisible();
                } catch (final Exception e) {
                    throw new RuntimeException("Error initializing TensorFlow!", e);
                }
            }
        });
    }

    private void makeButtonVisible() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                btnDetectObject.setVisibility(View.VISIBLE);
            }
        });
    }
}
