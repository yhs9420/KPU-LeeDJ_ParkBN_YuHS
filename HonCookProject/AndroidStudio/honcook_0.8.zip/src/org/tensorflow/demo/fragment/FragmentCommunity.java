package org.tensorflow.demo.fragment;

import android.app.Activity;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.tensorflow.demo.R;
import org.tensorflow.demo.activity.TestActivity;

public class FragmentCommunity extends Fragment {
    private LinearLayout cookingInforLayout;
    private LinearLayout recipeEvaluationLayout;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View v = inflater.inflate(R.layout.fragment_community, container, false);

        cookingInforLayout = v.findViewById(R.id.cookingInforLayout);
        recipeEvaluationLayout= v.findViewById(R.id.recipeEvaluationLayout);

        cookingInforLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "요리 정보 게시판", Toast.LENGTH_SHORT).show();
            }
        });

        recipeEvaluationLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "레시피 평가 게시판", Toast.LENGTH_SHORT).show();
            }
        });

        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        Activity activity = getActivity();
        if (activity != null) {
            ((TestActivity) activity).setCustomActionBar("커뮤니티");
        }
    }
}