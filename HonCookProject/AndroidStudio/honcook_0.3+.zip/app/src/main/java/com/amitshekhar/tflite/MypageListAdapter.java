package com.amitshekhar.tflite;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.List;

/**
 * Created by kch on 2018. 2. 17..
 */

public class MypageListAdapter extends BaseAdapter {


    private Context context;
    private List<Mypage> recipeList;
    private List<Mypage> saveList;

    public MypageListAdapter(Context context, List<Mypage> recipeList, List<Mypage> saveList){
        this.context = context;
        this.recipeList = recipeList;
        this.saveList = saveList;

    }

    //출력할 총갯수를 설정하는 메소드
    @Override
    public int getCount() {
        return recipeList.size();
    }

    //특정한 유저를 반환하는 메소드
    @Override
    public Object getItem(int i) {
        return recipeList.get(i);
    }

    //아이템별 아이디를 반환하는 메소드
    @Override
    public long getItemId(int i) {
        return i;
    }

    //가장 중요한 부분
    //int i 에서 final int i 로 바뀜 이유는 deleteButton.setOnClickListener에서 이 값을 참조하기 때문
    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.mypage, null);
        //뷰에 다음 컴포넌트들을 연결시켜줌
        //final추가 안붙이면 에러남 리스너로 전달하고 싶은 지역변수는 final로 처리해야됨

       // final TextView userID = (TextView)v.findViewById(R.id.userID);
       // TextView userAge = (TextView)v.findViewById(R.id.userAge);
        TextView recipe_name = (TextView)v.findViewById(R.id.recipe_name);
        TextView recipe_category = (TextView)v.findViewById(R.id.recipe_category);
        ImageView recipeImage = (ImageView)v.findViewById((R.id.recipeImage));

      //  userID.setText(recipeList.get(i).getUserID());
       // userAge.setText(recipeList.get(i).getUserAge());
        recipe_name.setText(recipeList.get(i).getRecipe_name());
        recipe_category.setText(recipeList.get(i).getRecipe_category());
        //이렇게하면 findViewWithTag를 쓸 수 있음 없어도 되는 문장임
      //  v.setTag(recipeList.get(i).getUserID());

        String rCategory = recipe_category.getText().toString();

        if("한식".equals(rCategory))
            recipeImage.setImageResource(R.drawable.korean);
        else if("중식".equals(rCategory))
            recipeImage.setImageResource(R.drawable.chinese);
        else if("일식".equals(rCategory))
            recipeImage.setImageResource(R.drawable.japanese);
        else if("양식".equals(rCategory))
            recipeImage.setImageResource(R.drawable.western);
        //만든뷰를 반환함

        Button detailButton = (Button)v.findViewById(R.id.detailButton);

        detailButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), MypageClickedActivity.class);
                intent.putExtra("recipe_name", recipeList.get(i).getRecipe_name());
                intent.putExtra("recipe_category", recipeList.get(i).getRecipe_category());
                intent.putExtra("recipe_ingredient", recipeList.get(i).getRecipe_ingredient());
                intent.putExtra("recipe_content", recipeList.get(i).getRecipe_content());
                context.startActivity(intent);

            }});
        return v;
    }

}

