package com.amitshekhar.tflite;

public class Mypage {
    String userID;
    String userAge;
    String recipe_name;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserAge() {
        return userAge;
    }

    public void setUserAge(String userAge) {
        this.userAge = userAge;
    }

    public String getRecipe_name() {
        return recipe_name;
    }

    public void setRecipe_name(String recipe_name) {
        this.recipe_name = recipe_name;
    }

    public Mypage(String userID, String userAge, String recipe_name) {
        this.userID = userID;
        this.userAge = userAge;
        this.recipe_name = recipe_name;
    }
}