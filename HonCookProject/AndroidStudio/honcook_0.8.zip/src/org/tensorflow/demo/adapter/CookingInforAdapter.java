package org.tensorflow.demo.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.tensorflow.demo.R;
import org.tensorflow.demo.list.CookingInfor;

import java.util.List;

/**
 * Created by kch on 2018. 2. 17..
 */

public class CookingInforAdapter extends BaseAdapter {

    private Context context;
    private List<CookingInfor> cookingInforList;
    private List<CookingInfor> saveList;

    public CookingInforAdapter(Context context, List<CookingInfor> cookingInforList, List<CookingInfor> saveList) {
        this.context = context;
        this.cookingInforList = cookingInforList;
        this.saveList = saveList;

    }


    //출력할 총갯수를 설정하는 메소드
    @Override
    public int getCount() {
        return cookingInforList.size();
    }

    //특정한 유저를 반환하는 메소드
    @Override
    public Object getItem(int i) {
        return cookingInforList.get(i);
    }

    //아이템별 아이디를 반환하는 메소드
    @Override
    public long getItemId(int i) {
        return i;
    }

    //가장 중요한 부분
    //int i 에서 final int i 로 바뀜 이유는 deleteButton.setOnClickListener에서 이 값을 참조하기 때문
    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.cookinginfor, null);

        final TextView board_name = (TextView) v.findViewById(R.id.board_name);
        TextView board_content = (TextView) v.findViewById(R.id.board_content);
        TextView board_writer = (TextView) v.findViewById(R.id.board_writer);

        board_name.setText(cookingInforList.get(i).getBoard_name());
        board_content.setText(cookingInforList.get(i).getBoard_content());
        board_writer.setText(cookingInforList.get(i).getBoard_writer());

        v.setTag(cookingInforList.get(i).getBoard_name());
        return v;
    }

}

